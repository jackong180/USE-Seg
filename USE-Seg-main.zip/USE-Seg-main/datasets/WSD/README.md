Place images/{train,val,test} and polygon labels/{train,val,test} here. See main README for class ordering.
