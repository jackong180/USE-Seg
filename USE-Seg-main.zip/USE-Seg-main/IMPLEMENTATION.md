# 方法与代码对照

## UADConv / UBS

实现顺序为：

1. `z = Conv1x1(x, stride=s)`，输出通道为 c2。
2. 局部窗口默认 3×3：`mu = AvgPool(z)`，`var = max(AvgPool(z²)-mu²,0)`，`dev = |z-mu|`。
3. `u = sigmoid(Conv1x1(concat[z,mu,var,dev]))`，单通道空间不确定性图。
4. 四路 depthwise 卷积：k×k、1×k、k×1、dilation=2 的 k×k，默认 k=3。
5. `w = softmax(Conv1x1(concat[z,u]), dim=1)`，生成四路逐位置权重，权重和为1。
6. `f = sum(w_i * branch_i(z))`；`f_enhanced = f * (1+tanh(alpha)*u)`。
7. `y = SiLU(BN(Conv1x1(f_enhanced)+skip(x)))`；通道或步长不一致时使用 1×1 skip 投影。

骨干五个步长2的独立 Conv 替换为 UADConv。Neck 两个独立下采样 Conv 保留原实现。原 C2f 在骨干与 Neck 中均替换为 US2f。Segment 的原型掩膜生成、检测与掩膜系数分支保留。

论文文本中的公式对象未全部提取为可读文本，因此以下是本次明确采用的工程选择：统计窗口3、绝对偏差、单通道不确定性、投影后统计、1×1步长投影下采样、tanh约束增强系数、默认三点方向核。后续如论文原公式不同，应据原公式调整并重新评估。

`UADConv` 类包含 BN/SiLU，即实现论文中的 UBS 整体，避免在 US2f 再重复归一化。k=1 的通道映射单元仍保留不确定性与四路融合，不过方向核退化为点卷积；Bottleneck 内使用 k=3。

## US2f

首个 UBS 映射到隐藏通道 c（默认约 c2/2，向上取4的倍数）。将完整 z 的通道划分为4组并重排；保留完整 z、shuffle(z)，对后者连续施加 n 个双 UBS Bottleneck，最后拼接 (2+n)c 通道，经末端 UBS 压缩为 c2。不使用原 C2f 的两半 chunk。

随机性处理：每个 US2f 初始化时抽取一次 `randperm(4)` 并注册为 buffer，训练和推理共用，state_dict 保留排列。`run.py` 在建模前固定种子。论文只描述随机排列，没有规定每次前向是否重采样；这里选择固定随机排列以获得确定性推理，不声称与历史实验随机策略完全一致。排列可能为恒等排列，这是均匀随机抽样的正常结果。

## EAA

`p=softmax(x/T, dim=channel)`，`H=-sum(p*log(p))/log(C)`，`a=max(0,1-H)`，再对各样本空间最大值归一化，`y=x+gamma*x*a`。gamma 初始0，保持初始恒等映射。熵在 FP32 下计算。

上传代码直接计算 `1-H`，未按 log(C) 归一化；C较大时权重可能为负，最大值接近0时可能放大响应。因此本工程 EAA 使用有界归一化熵，这是明确的数学修正，并非与原代码逐值等价。原 `block.py::EntropyAttention` 保留用于追溯，但完整模型使用独立 `eaa.py::EAA`。

三个 EAA 的输入是网络层15、18、21（P3/P4/P5），对应新层22、23、24；层25 Segment 接收 [22,23,24]。只在预测前增强，避免改变PAN融合索引。

## 清理与兼容

- 保留上传源码版本8.4.150，不将整个框架降级到历史版本。
- 原 `yolov8-seg.yaml` 保留。原 `yolov8.yaml` 曾插入注意力却未更新后续索引，现从同包原始v8-seg骨干/Neck恢复标准检测拓扑。
- `parse_model` 注册 UADConv/US2f 的通道缩放及 US2f 的内部重复次数；EAA/EntropyAttention 显式继承输入通道数。
- 全部 USE-Seg 配置均以独立 configs 文件交付，默认7类。
- 历史 best.pt 未确认模型结构，因此未复制，也未宣称兼容所有旧 checkpoint。
- 许可证保留；上游 CITATION.cff 只代表基础库来源，不代表 USE-Seg 论文引用。
