"""Offline checks for all five configurations; no pretrained weights needed."""
from pathlib import Path
from types import SimpleNamespace
import torch
from ultralytics import YOLO
from ultralytics.nn.modules import UADConv, US2f, EAA


def main():
    torch.set_num_threads(2)
    torch.manual_seed(0)
    root = Path(__file__).resolve().parent
    for module in (UADConv(8, 16, 3, 2), US2f(8, 16, 2, True), EAA()):
        x = torch.randn(2, 8, 31, 35, requires_grad=True)
        y = module(x)
        assert torch.isfinite(y).all()
        y.square().mean().backward()
        assert x.grad is not None and torch.isfinite(x.grad).all()
        print(type(module).__name__, tuple(y.shape), 'gradient OK')
    for name in ('baseline', 'uadconv', 'us2f', 'eaa', 'use-seg'):
        wrapper = YOLO(str(root / 'configs' / (name + '.yaml')), task='segment')
        model = wrapper.model
        model.args = SimpleNamespace(**model.args)
        assert model.stride.tolist() == [8, 16, 32]
        model.train()
        masks = torch.zeros(2, 32, 32)
        masks[:, 8:24, 8:24] = 1
        batch = dict(img=torch.rand(2, 3, 128, 128), batch_idx=torch.tensor([0., 1.]),
                     cls=torch.tensor([[0.], [1.]]),
                     bboxes=torch.tensor([[.5, .5, .5, .5], [.5, .5, .5, .5]]), masks=masks)
        loss, items = model(batch)
        assert torch.isfinite(loss).all()
        loss.sum().backward()
        for p in model.parameters():
            if p.grad is not None:
                assert torch.isfinite(p.grad).all()
        model.eval()
        with torch.no_grad():
            out = model(torch.rand(1, 3, 128, 160))
        print(name, 'params', sum(p.numel() for p in model.parameters()), 'loss', items, 'eval OK')
    print('PASS: module gradients, 5 model builds, strides, segmentation loss/backward and rectangular inference')


if __name__ == '__main__':
    main()
