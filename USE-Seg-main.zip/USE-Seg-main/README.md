# USE-Seg-main

基于用户上传的 Ultralytics 8.4.150 源码，集成 UADConv、US2f、EAA 的 YOLOv8s 实例分割工程。

**实现来源：** 上传包没有 UADConv、US2f。本工程经用户授权，依据 T-ASE.docx 方法部分补写两模块；EAA 在原 EntropyAttention 基础上作数值修正。它是可训练的重建实现，不是已验证可复现论文指标的原实验代码。数据集和经过确认的 USE-Seg 训练权重未随包提供；原包 best.pt 身份未确认，未作为 USE-Seg 权重打包。

## 文件入口

| 文件 | 用途 |
|---|---|
| `ultralytics/nn/modules/uadconv.py` | UADConv（含外层 BN、SiLU，即 UBS） |
| `ultralytics/nn/modules/us2f.py` | US2f、UADBottleneck、四组随机排列 |
| `ultralytics/nn/modules/eaa.py` | EAA 注意力 |
| `ultralytics/nn/tasks.py` | YAML 模块解析、通道缩放与重复次数注册 |
| `ultralytics/nn/modules/__init__.py` | 模块导出 |
| `configs/use-seg.yaml` | 完整 USE-Seg Small 网络 |
| `configs/baseline.yaml` | 原始 YOLOv8s-Seg、7 类 |
| `configs/uadconv.yaml`, `us2f.yaml`, `eaa.yaml` | 单模块消融配置 |
| `configs/WSD.yaml` | 数据配置 |
| `run.py` | 训练、验证、推理、导出统一入口 |
| `verify.py` | 无需数据集的结构、分割损失、反向传播检查 |
| `IMPLEMENTATION.md` | 计算公式、设计选择、与原包差异 |
| `VALIDATION.md` | 本次实际验证范围与结果 |

保留完整 `ultralytics/` 运行包，避免删掉训练、验证、导出等路径的间接依赖；不打包原仓库网站文档、CI、IDE 缓存、运行结果及无关图片。保留 AGPL-3.0 LICENSE 与上游 CITATION.cff。

## 安装

建议在独立 Python 3.11 环境中使用，先按本机 CUDA 环境安装匹配的 PyTorch/torchvision，再安装本地工程。

```bash
cd USE-Seg-main
python -m pip install -e .
python -c "import ultralytics; print(ultralytics.__file__)"
python verify.py
```

打印路径应指向本工程。不要随后用 `pip install -U ultralytics` 覆盖本地修改。CPU 可运行检查；实际训练建议使用 GPU。依赖声明保留上传源码的 pyproject.toml；本工程新增模块只依赖 PyTorch。

## 数据集

编辑 `configs/WSD.yaml` 的 `path`，推荐使用数据根目录的绝对路径（Windows 使用正斜杠）。该目录下放置 `images/train`、`images/val`、`images/test` 和对应的 `labels/train`、`labels/val`、`labels/test`。

标签必须是 YOLO 多边形分割格式：`class x1 y1 x2 y2 ...`，坐标归一化到 [0,1]，不能用仅有中心与宽高的检测框标签代替。

本工程采用原训练入口所指向的配置顺序：

| ID | 类别 |
|---|---|
| 0 | PARTICLE |
| 1 | PIQ PARTICLE |
| 2 | SCRATCH |
| 3 | COATING BAD |
| 4 | PO CONTAMINATION |
| 5 | BLOCK ETCH |
| 6 | SEZ BURNT |

原包 `datasets/WSD.yaml` 与 `ultralytics/cfg/datasets/WSD.yaml` 顺序不一致。这里统一使用后者，但**没有修改实际标签**；训练前必须核对导出数据的 class ID。改 YAML 名称不会自动重映射标签。

## 训练

```bash
python run.py train --device 0 --epochs 200 --batch 2 --workers 0
python run.py train --model configs/baseline.yaml --name baseline --device 0
python run.py train --model configs/uadconv.yaml --name UADConv --device 0
python run.py train --model configs/us2f.yaml --name US2f --device 0
python run.py train --model configs/eaa.yaml --name EAA --device 0
```

默认从头训练、SGD、lr0=0.01、640 输入、随机种子 0，每10个epoch额外保存。所有配置固定 Small 的 depth=0.33、width=0.50，不依靠文件名猜测型号。消融中 US2f 自身已经包含 UADConv；`us2f.yaml` 表示只替换 C2f，不替换骨干独立 Conv。

可选 `--weights /path/to/checkpoint.pt` 初始化兼容参数，新增结构无法从原 YOLO 权重完整加载；请核对加载日志，这不等同于恢复训练。若需要断点恢复，可使用原生接口 `YOLO('runs/segment/USE-Seg/weights/last.pt').train(resume=True)`。

## 验证、推理、导出

```bash
python run.py val --weights runs/segment/USE-Seg/weights/best.pt --split test --device 0
python run.py predict --weights runs/segment/USE-Seg/weights/best.pt --source path/to/images --device 0
python run.py export --weights runs/segment/USE-Seg/weights/best.pt --format onnx --device cpu
```

导出入口沿用上游实现，目标格式可能需要额外依赖；本次未验证 ONNX/TensorRT/RKNN 部署。执行 `python run.py --help` 查看全部参数。仅 CPU 时改为 `--device cpu`。

## 实验边界

不包含 WSD 真实数据和已训练 USE-Seg 权重，不能保证论文中 Mask AP50=74.9%、Box mAP50=78.8% 或 FPS。必须在统一数据划分和测试平台上重新训练、评估。本文代码的明确工程选择详见 IMPLEMENTATION.md。
