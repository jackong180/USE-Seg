"""Train, validate, predict or export USE-Seg from the local source package."""
import argparse
from pathlib import Path
from multiprocessing import freeze_support

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['train', 'val', 'predict', 'export'])
    parser.add_argument('--model', default=str(ROOT / 'configs/use-seg.yaml'))
    parser.add_argument('--weights', help='Local checkpoint; required for val/predict/export')
    parser.add_argument('--data', default=str(ROOT / 'configs/WSD.yaml'))
    parser.add_argument('--source', help='Image, directory or video for prediction')
    parser.add_argument('--epochs', type=int, default=200)
    parser.add_argument('--imgsz', type=int, default=640)
    parser.add_argument('--batch', type=int, default=2)
    parser.add_argument('--workers', type=int, default=0)
    parser.add_argument('--device', default='0')
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--name', default='USE-Seg')
    parser.add_argument('--split', default='val', choices=['train', 'val', 'test'])
    parser.add_argument('--format', default='onnx')
    args = parser.parse_args()
    if args.mode != 'train' and not args.weights:
        parser.error('--weights is required for val/predict/export')
    if args.mode == 'predict' and not args.source:
        parser.error('--source is required for predict')
    from ultralytics import YOLO
    from ultralytics.utils.torch_utils import init_seeds
    init_seeds(args.seed, deterministic=True)
    model = YOLO(args.model if args.mode == 'train' else args.weights, task='segment')
    if args.mode == 'train':
        if args.weights:
            model.load(args.weights)
        model.train(data=args.data, epochs=args.epochs, imgsz=args.imgsz, batch=args.batch,
                    workers=args.workers, device=args.device, optimizer='SGD', lr0=0.01,
                    momentum=0.937, weight_decay=0.0005, seed=args.seed, deterministic=True,
                    save_period=10, project=str(ROOT / 'runs/segment'), name=args.name)
    elif args.mode == 'val':
        model.val(data=args.data, split=args.split, imgsz=args.imgsz, batch=args.batch,
                  workers=args.workers, device=args.device)
    elif args.mode == 'predict':
        model.predict(source=args.source, imgsz=args.imgsz, device=args.device,
                      save=True, project=str(ROOT / 'runs/predict'), name=args.name)
    else:
        model.export(format=args.format, imgsz=args.imgsz, device=args.device)


if __name__ == '__main__':
    freeze_support()
    main()
