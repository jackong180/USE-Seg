"""US2f: original/shuffled paths and uncertainty-aware bottleneck aggregation."""
import torch
from torch import nn
from .uadconv import UADConv


class UADBottleneck(nn.Module):
    """Two UBS units with an optional short residual connection."""

    def __init__(self, channels, shortcut=True):
        super().__init__()
        self.cv1 = UADConv(channels, channels, 3)
        self.cv2 = UADConv(channels, channels, 3)
        self.shortcut = shortcut

    def forward(self, x):
        y = self.cv2(self.cv1(x))
        return x + y if self.shortcut else y


class US2f(nn.Module):
    """Keep full original and four-group-permuted features, then aggregate n stages.

    A random group permutation is sampled at initialization and saved as a
    buffer, ensuring reproducible inference and consistent checkpoint reloads.
    """

    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5):
        super().__init__()
        if g != 1:
            raise ValueError("US2f uses depthwise directional branches; g must be 1")
        self.c = max(4, int(c2 * e + 3) // 4 * 4)
        self.cv1 = UADConv(c1, self.c, 1)
        self.cv2 = UADConv((2 + n) * self.c, c2, 1)
        self.m = nn.ModuleList(UADBottleneck(self.c, shortcut) for _ in range(n))
        self.register_buffer("permutation", torch.randperm(4))

    def forward(self, x):
        z = self.cv1(x)
        b, c, h, w = z.shape
        shuffled = z.reshape(b, 4, c // 4, h, w).index_select(1, self.permutation).reshape(b, c, h, w)
        features = [z, shuffled]
        features.extend(block(features[-1]) for block in self.m)
        return self.cv2(torch.cat(features, dim=1))
