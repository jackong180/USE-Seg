"""Entropy-driven adaptive attention with bounded entropy normalization."""
import math
import torch
from torch import nn


class EAA(nn.Module):
    """Channel entropy -> inverse entropy -> spatial maximum normalization.

    Entropy is divided by log(C) before inversion to prevent negative weights.
    The original archive implementation is retained as EntropyAttention.
    """

    def __init__(self, temperature=1.0, eps=1e-6):
        super().__init__()
        if temperature <= 0 or eps <= 0:
            raise ValueError("temperature and eps must be positive")
        self.temperature, self.eps = temperature, eps
        self.gamma = nn.Parameter(torch.zeros(1))

    def forward(self, x):
        if x.shape[1] == 1:
            attention = torch.ones_like(x)
        else:
            log_p = (x.float() / self.temperature).log_softmax(dim=1)
            entropy = -(log_p.exp() * log_p).sum(dim=1, keepdim=True) / math.log(x.shape[1])
            attention = (1 - entropy).clamp(0, 1)
            attention = attention / attention.amax(dim=(2, 3), keepdim=True).clamp_min(self.eps)
        return x + self.gamma * x * attention.to(x.dtype)
