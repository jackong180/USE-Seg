"""Uncertainty-aware directional convolution reconstructed from the USE-Seg method."""
import torch
from torch import nn
from torch.nn import functional as F


class UADConv(nn.Module):
    """Local-statistics gating of four depthwise branches, projection and residual.

    This layer includes the outer BatchNorm and SiLU (UBS). Kernel size k is
    odd; the default directional branches are k*k, 1*k, k*1 and dilated k*k.
    """

    def __init__(self, c1, c2, k=3, s=1, window=3):
        super().__init__()
        if k < 1 or k % 2 == 0 or window < 1 or window % 2 == 0:
            raise ValueError("k and window must be positive odd integers")
        self.window = window
        self.project = nn.Conv2d(c1, c2, 1, stride=s, bias=False)
        self.uncertainty = nn.Conv2d(4 * c2, 1, 1)
        self.gate = nn.Conv2d(c2 + 1, 4, 1)
        self.branches = nn.ModuleList([
            nn.Conv2d(c2, c2, k, padding=k // 2, groups=c2, bias=False),
            nn.Conv2d(c2, c2, (1, k), padding=(0, k // 2), groups=c2, bias=False),
            nn.Conv2d(c2, c2, (k, 1), padding=(k // 2, 0), groups=c2, bias=False),
            nn.Conv2d(c2, c2, k, padding=k - 1, dilation=2, groups=c2, bias=False),
        ])
        self.alpha = nn.Parameter(torch.zeros(1))
        self.output = nn.Conv2d(c2, c2, 1, bias=False)
        self.skip = nn.Identity() if c1 == c2 and s == 1 else nn.Conv2d(c1, c2, 1, s, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU()

    def forward(self, x):
        """Fuse directional responses using spatial uncertainty-conditioned weights."""
        z = self.project(x)
        # Compute variance in FP32, including under autocast.
        z32 = z.float()
        mu = F.avg_pool2d(z32, self.window, 1, self.window // 2, count_include_pad=False)
        var = (F.avg_pool2d(z32.square(), self.window, 1, self.window // 2,
                            count_include_pad=False) - mu.square()).clamp_min(0)
        deviation = (z32 - mu).abs()
        stats = torch.cat((z32, mu, var, deviation), dim=1).to(z.dtype)
        u = torch.sigmoid(self.uncertainty(stats))
        weights = self.gate(torch.cat((z, u), dim=1)).float().softmax(1).to(z.dtype)
        fused = sum(branch(z) * weights[:, i:i + 1] for i, branch in enumerate(self.branches))
        enhanced = fused * (1 + self.alpha.tanh() * u)
        return self.act(self.bn(self.output(enhanced) + self.skip(x)))
