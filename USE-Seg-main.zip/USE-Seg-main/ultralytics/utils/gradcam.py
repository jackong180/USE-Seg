import cv2
import numpy as np
import torch

class ActivationsAndGradients:
    """
    保存指定层的 Feature Map 和 Gradient
    """

    def __init__(self, model, target_layer):

        self.model = model

        self.gradients = []

        self.activations = []

        self.handles = []

        self.handles.append(
            target_layer.register_forward_hook(
                self.save_activation
            )
        )

        self.handles.append(
            target_layer.register_full_backward_hook(
                self.save_gradient
            )
        )

    def save_activation(self, module, input, output):

        self.activations.append(
            output.detach()
        )

    def save_gradient(self, module, grad_input, grad_output):

        self.gradients.insert(
            0,
            grad_output[0].detach()
        )

    def release(self):

        for handle in self.handles:

            handle.remove()

class GradCAM:

    def __init__(self, model, target_layer):

        self.model = model

        self.model.eval()

        self.activations_and_grads = ActivationsAndGradients(
            model,
            target_layer
        )

    def get_cam_weights(self, gradients):

        return gradients.mean(
            dim=(2,3),
            keepdim=True
        )

    def get_cam_image(
            self,
            activations,
            gradients
    ):

        weights = self.get_cam_weights(
            gradients
        )

        cam = (weights * activations).sum(
            dim=1
        )

        cam = torch.relu(cam)

        return cam

    def normalize(self, cam):

        cam = cam - cam.min()

        cam = cam / (cam.max() + 1e-7)

        return cam

    def resize_cam(self, cam, image):

        cam = cv2.resize(

            cam,

            (image.shape[1], image.shape[0])

        )

        return cam

    def overlay(self, image, cam):
        # -----------------------------
        # 1. 去除低响应区域
        # -----------------------------
        cam = cam.copy()

        threshold = 0.15  # 可调(0.1~0.2)

        cam[cam < threshold] = 0

        # -----------------------------
        # 2. Heatmap
        # -----------------------------
        heatmap = np.uint8(cam * 255)

        heatmap = cv2.applyColorMap(
            heatmap,
            cv2.COLORMAP_JET
        )

        heatmap = cv2.cvtColor(
            heatmap,
            cv2.COLOR_BGR2RGB
        )

        # -----------------------------
        # 3. 浅蓝色背景
        # -----------------------------
        image = image.astype(np.float32)

        blue = np.zeros_like(image)

        blue[:, :, 0] = 220
        blue[:, :, 1] = 240
        blue[:, :, 2] = 255

        # 20%浅蓝色蒙版
        background = cv2.addWeighted(
            image,
            0.40,
            blue,
            0.60,
            0
        )

        # -----------------------------
        # 4. 仅目标区域叠加Heatmap
        # -----------------------------
        mask = cam > threshold

        overlay = background.copy()

        alpha = 0.55

        overlay[mask] = (
                background[mask] * (1 - alpha)
                + heatmap[mask] * alpha
        )

        overlay = np.clip(
            overlay,
            0,
            255
        ).astype(np.uint8)

        return overlay

    def forward(self, image):
        self.model.zero_grad()

        image = image.float()
        image.requires_grad_(True)

        with torch.enable_grad():
            output = self.model(image)

        pred = output[0][0]

        proto = output[0][1]

        return pred, proto

    def backward(self, pred):
        # 类别数
        nc = 7  # 后面再改成自动读取

        # 取类别预测
        cls_scores = pred[
            0,
            4:4 + nc,
            :
        ]  # (7,8400)

        # 每个类别最大分数
        score, index = cls_scores.max(dim=1)

        # 找到总体最高类别
        cls = score.argmax()

        # 找到对应anchor
        anchor = index[cls]

        # 最终反向传播的score
        target_score = cls_scores[
            cls,
            anchor
        ]

        target_score.backward(
            retain_graph=True
        )

        return cls.item()

    def generate_cam(self):
        gradients = self.activations_and_grads.gradients[-1]

        activations = self.activations_and_grads.activations[-1]

        cam = self.get_cam_image(

            activations,

            gradients

        )

        cam = cam.squeeze()

        cam = cam.cpu().numpy()

        cam = self.normalize(cam)

        return cam

    def __call__(self, image):
        pred, proto = self.forward(image)

        cls = self.backward(pred)

        print("Target Class:", cls)

        cam = self.generate_cam()

        img = image.detach()[0].permute(1, 2, 0).cpu().numpy()

        img = np.uint8(img * 255)

        cam = self.resize_cam(cam, img)

        overlay = self.overlay(img, cam)

        return overlay